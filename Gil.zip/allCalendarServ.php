<?php
/*
 * Copyright 2013 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
 
 
include_once "google-api-php-client-master/examples/templates/base.php";
session_start();

require_once realpath(dirname(__FILE__) . '/google-api-php-client-master/autoload.php');

require_once "mydb.php";
require_once "spreadsheet.php";

$newOrdersCalendarID = 'mqi24otrn0likjldo9aqb1j798@group.calendar.google.com';
 
$clientid = '457875993449-48gmkqssiulu00va3vtrlvg297pv1j8u.apps.googleusercontent.com';
$clientmail = '457875993449-48gmkqssiulu00va3vtrlvg297pv1j8u@developer.gserviceaccount.com';
$clientkeypath = 'API Project-0ffd21d566b5.p12';

$client = new Google_Client();
$client->setApplicationName("gil");
$client->setClientId($clientid);
$service = new Google_Service_Calendar($client);

/************************************************
  If we have an access token, we can carry on.
  Otherwise, we'll get one with the help of an
  assertion credential. In other examples the list
  of scopes was managed by the Client, but here
  we have to list them manually. We also supply
  the service account
 ************************************************/
if (isset($_SESSION['service_token'])) {
  $client->setAccessToken($_SESSION['service_token']);
}
$key = file_get_contents($clientkeypath);
$cred = new Google_Auth_AssertionCredentials(
    $clientmail,
    array('https://www.googleapis.com/auth/calendar',
    		 'https://spreadsheets.google.com/feeds'),
    $key
);
$client->setAssertionCredentials($cred);

while (true) {
	
		set_time_limit (0); // run forever
			  
		
		if ($client->getAuth()->isAccessTokenExpired()) {
		  $client->getAuth()->refreshTokenWithAssertion($cred);
		}
			   
		if ($client->getAccessToken()) {
			  	$_SESSION['service_token'] = $client->getAccessToken();
			
			// select rows not updated	
			
			//echo "updating spreadsheet";
		   //$dataRow = getFromSpreadsheet($client);
		   		
			$eventID = null;
			$sql = "SELECT * FROM calendars WHERE updated='0'";
			$result = mysql_query($sql) or die('Select Row Failed! ' . mysql_error()); 
			if ((mysql_num_rows($result) > 0) && ($DBEvent = mysql_fetch_array($result))) {
						$orderID = $DBEvent["orderID"];
			    		$calendar = $DBEvent["calendar"];
		   			$dateArray = explode(" ", $DBEvent["date"], 2);
		   			// Format the date and time to calendar format
		   			$date = $dateArray[0]."T".$dateArray[1]."Z";
		   			//echo "date: ".$date;

			         echo "found order ". $orderID. "<br>"; 
						$sql = "SELECT * FROM orders WHERE number='$orderID'";
						$result = mysql_query($sql) or die('Select Row Failed! ' . mysql_error()); 
						if ((mysql_num_rows($result) > 0) && ($order = mysql_fetch_array($result))) {
							$orderName = $order["name"];
							$customerID = $order["customerID"];
							$sql = "SELECT * FROM customers WHERE ID ='$customerID'";
							$result = mysql_query($sql) or die('Select Row Failed! ' . mysql_error()); 
							if ((mysql_num_rows($result) > 0) && ($customer = mysql_fetch_array($result))) {
								$customerName = $customer["name"];
								$address = $customer["address"];
								
							}
								
			         }	
		    }
			 else { 
			 	//echo "No order to update<br>";
				flush();
			  	sleep(1);
			  	continue;
			}	
	
	    	$event = null;
			if ($eventID && $eventID != ""){
				// look for the event in the calendar
		    	$list = $service->events->listEvents($calendarID);	
				foreach($list["items"] as $eventx) {
					//echo $event["htmlLink"];
					if ($eventID == $eventx["id"] || strpos($eventx["htmlLink"], $eventID ) != false) {
		    			echo " found event ". $eventID."<br>";
		    			$event = $eventx;
		    			break;
					}	
				
				}
			}
			$new = false;
			if (!$event) {
				echo "Event doesn't exist - creating new...";
				$event = new Google_Service_Calendar_Event();
				$new = true;
			}
			else {
				
			}
		   		
			$event->setSummary($orderName);
			$event->setLocation($address);
		
			$start = new Google_Service_Calendar_EventDateTime();
			$start->setDateTime($date);
			$event->setStart($start);
			$end = new Google_Service_Calendar_EventDateTime();
			$end->setDateTime($date);
			$event->setEnd($end);
			//$event->setDescription($description);
			// all day event ?
/*
			
			$gadget = new Google_Service_Calendar_EventGadget();
			$gadget->setDisplay("chip");
			$gadget->setIconLink("https://localhost/gil/done.jpg");
			$gadget->setLink("https://amosgery.5gbfree.com/gil/myEvents1.xml");
			//$gadget->setType("application/x-google-gadgets+xml");
		  	$gadget->setHeight(236);
		   $gadget->setWidth(600);
			$gadget->setType("html");
			$gadget->setTitle("Gil's Gadget");
			
			$event->gadget = $gadget;
*/			
			$attendee1 = new Google_Service_Calendar_EventAttendee();
			$attendee1->setEmail('gildavidov7@gmail.com');
			// ...
			$attendees = array($attendee1,
			                   // ...
			                  );
			//$event->attendees = $attendees;

			try {
				if($new) {
					$updatedEvent = $service->events->insert($newOrdersCalendarID, $event);
					$eidpos = strpos($updatedEvent["htmlLink"], "eid=" ); // find the event ID that will show up in the map gadget
					$eventID = substr($updatedEvent["htmlLink"], $eidpos+4);
					$event = $updatedEvent;
		
				}
				// update the description with a link to update the event
				$event->setDescription("<p>Customer ID :".$customerID."</p><br><a href='https://".$hostname."/gil/?id=".$eventID."#/updateOrder'>Update</a>");
				$updatedEvent = $service->events->update($newOrdersCalendarID, $event->getId(), $event);

				$sql = "UPDATE calendars set eventID='$eventID', updated='1' WHERE orderID='$orderID'";
				$result = mysql_query($sql) or die('Update order eventID Failed! ' . mysql_error());

				echo " Event created: " . $eventID ;
			}

			//catch exception
			catch(Exception $e) {
				  echo 'Exception: ' .$e->getMessage(). "<br>";
				  sleep(1);
				  continue;
			}	

			
		} 
		else {
				echo "could not access calendar";
				return;
		}  

} // while (true)

?>



