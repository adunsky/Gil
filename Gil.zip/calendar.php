<?php
/*
 * Copyright 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
include_once "google-api-php-client-master/examples/templates/base.php";
session_start();

require_once realpath(dirname(__FILE__) . '/google-api-php-client-master/autoload.php');

require_once "mydb.php";
require_once "spreadsheet.php";

/************************************************
  ATTENTION: Fill in these values! Make sure
  the redirect URI is to this page, e.g:
  http://localhost:8080/user-example.php
 ************************************************/
 $client_id = '949470023217-22oljsn3tid1qm113k1otc6qpo8qaidl.apps.googleusercontent.com';
 $client_secret = 'TYC7ZjKWZoMQup2ZvsLYrTNp';
 $redirect_uri = 'http://'.$hostname.'/gil/calendar.php';
 
 
 $calendarID = 'l7sf224d4l7u260j5u2hcv8008@group.calendar.google.com'; // gil

/************************************************
  Make an API request on behalf of a user. In
  this case we need to have a valid OAuth 2.0
  token for the user, so we need to send them
  through a login flow. To do this we need some
  information from our API console project.
 ************************************************/

$client = new Google_Client();
$client->setClientId($client_id);
$client->setClientSecret($client_secret);
$client->setRedirectUri($redirect_uri);

$client->addScope("https://www.googleapis.com/auth/calendar");

$service = new Google_Service_Calendar($client);

/************************************************
  Boilerplate auth management - see
  user-example.php for details.
 ************************************************/
if (isset($_REQUEST['logout'])) {
  unset($_SESSION['access_token']);
}
if (isset($_GET['code'])) {
  $client->authenticate($_GET['code']);
  $_SESSION['access_token'] = $client->getAccessToken();
  $redirect = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
  header('Location: ' . filter_var($redirect, FILTER_SANITIZE_URL));
}

if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
  $client->setAccessToken($_SESSION['access_token']);
} else {
  $authUrl = $client->createAuthUrl();
}


while (true) {
	
		set_time_limit (0); // run forever
		try {
			if($client->isAccessTokenExpired()) {
				 //$client->refreshToken($client->getAccessToken());
				 
			    $authUrl = $client->createAuthUrl();
			    header('Location: ' . filter_var($authUrl, FILTER_SANITIZE_URL));
			
			}
		} 
		//catch exception
		catch(Exception $e) {
			  echo 'Exception: ' .$e->getMessage(). "<br>";
			  sleep(5);
			  continue;
		}	 
			   
		if ($client->getAccessToken()) {
			  	$_SESSION['access_token'] = $client->getAccessToken();
			
		// select rows with update time > curr time			

			$sql = "SELECT * FROM orders WHERE updated='0'";
			$result = mysql_query($sql) or die('Select Row Failed! ' . mysql_error()); 
			if ((mysql_num_rows($result) > 0) && ($order = mysql_fetch_array($result))) {
						$number = $order["number"];
			    		$eventID = $order["eventID"];
		   			$location = $order["location"];
		   			$date1 = $order["date1"]."T12:00:00Z";
		   			$name = $order["name"];
		   			$customerID = $order["customerID"];
		   			$description = "<a href='https://".$hostname."/gil/?id=".$eventID."#/updateOrder'>Update</a>";
			         echo "found order ". $number. "<br>"; 
		    }
			 else { 
			 	echo "No order to update<br>";
				ob_flush();
			  	sleep(1);
			  	continue;
			}	
	
	    	$event = null;
			if ($eventID && $eventID != ""){
				// look for the event in the calendar
		    	$list = $service->events->listEvents($calendarID);	
				foreach($list["items"] as $eventx) {
					//echo $event["htmlLink"];
					if ($eventID == $eventx["id"] || strpos($eventx["htmlLink"], $eventID ) != false) {
		    			echo " found event ". $eventID."<br>";
		    			$event = $eventx;
		    			break;
					}	
				
				}
			}
			$new = false;
			if (!$event) {
				echo "Event doesn't exist - creating new...";
				$event = new Google_Service_Calendar_Event();
				$new = true;
			}
			else {
				
			}
		
			$event->setSummary($name);
			$event->setLocation($location);
		
			$start = new Google_Service_Calendar_EventDateTime();
			$start->setDateTime($date1);
			$event->setStart($start);
			$end = new Google_Service_Calendar_EventDateTime();
			$end->setDateTime($date1);
			$event->setEnd($end);
			$event->setDescription($description);
			// all day event ?
/*
			
			$gadget = new Google_Service_Calendar_EventGadget();
			$gadget->setDisplay("chip");
			$gadget->setIconLink("https://localhost/gil/done.jpg");
			$gadget->setLink("https://amosgery.5gbfree.com/gil/myEvents1.xml");
			//$gadget->setType("application/x-google-gadgets+xml");
		  	$gadget->setHeight(236);
		   $gadget->setWidth(600);
			$gadget->setType("html");
			$gadget->setTitle("Gil's Gadget");
			
			$event->gadget = $gadget;
*/			
			$attendee1 = new Google_Service_Calendar_EventAttendee();
			$attendee1->setEmail('gildavidov7@gmail.com');
			// ...
			$attendees = array($attendee1,
			                   // ...
			                  );
			//$event->attendees = $attendees;
			//echo "before: ".$customerID;
		   $customerID = updateSpreadsheet($customerID);
		   //echo "After: " .$customerID;
			try {
				if($new) {
					$updatedEvent = $service->events->insert($calendarID, $event);
					$eidpos = strpos($updatedEvent["htmlLink"], "eid=" ); // find the event ID that will show up in the map gadget
					$eventID = substr($updatedEvent["htmlLink"], $eidpos+4);
					$sql = "UPDATE orders set eventID='$eventID', customerID='$customerID', updated='1' WHERE number='$number'";
					$result = mysql_query($sql) or die('Update order eventID Failed! ' . mysql_error());

					echo " Event created: " . $eventID ;
		
				}
				else {
					$updatedEvent = $service->events->update($calendarID, $event->getId(), $event);
					$sql = "UPDATE orders set customerID='$customerID', updated='1' WHERE number='$number'";
					$result = mysql_query($sql) or die('Update order eventID Failed! ' . mysql_error());
					
					echo " Event updated: " . $eventID ;
				}
			}

			//catch exception
			catch(Exception $e) {
				  echo 'Exception: ' .$e->getMessage(). "<br>";
				  sleep(1);
				  continue;
			}	

			
		} 
		else {
				echo "could not access calendar";
				return;
		}  

	

} // while (true)

?>
