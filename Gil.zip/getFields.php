<?php  
   /*
   * Collect all Details from Angular HTTP Request.
   */ 
	require_once "mydb.php";
		 
   //var_dump($_GET);
	
	$sql = "SELECT * FROM $fieldTable;";
	$result = mysql_query($sql) or die('get fields Failed! ' . mysql_error()); 
	if (mysql_num_rows($result) > 0)	{
		//  found fields
		$row = [];

		while ($column = mysql_fetch_array($result)) {
			array_push($row, $column);	
		}
	}
	else {
		echo " Columns not found in table" ;
	}
			
	echo json_encode($row);	
	

?>