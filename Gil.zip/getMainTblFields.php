<?php  
   /*
   * Collect all Details from Angular HTTP Request.
   */ 
	require_once "mydb.php";
		 
   //var_dump($_GET);
	
	$eventID = $_GET["eventID"];

	$sql = "SELECT COLUMN_NAME, COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '$mainTable'";
	$result = mysql_query($sql) or die('get columns Failed! ' . mysql_error()); 
	if (mysql_num_rows($result) > 0)	{
		//  found columns
		$field = [];
		$row = [];

		while ($column = mysql_fetch_array($result)) {
			$field["name"] = $column["COLUMN_NAME"];
			$field["type"] = $column["COLUMN_TYPE"];
			$field["value"] = " ";
			array_push($row, $field);	
		}
	}
	else {
		echo " Columns not found in table" ;
	}
			
	echo json_encode($row);	
	
 	if ($eventID) {
		// get specific row 	
 	
 	}

?>